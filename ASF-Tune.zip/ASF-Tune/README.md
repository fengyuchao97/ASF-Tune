# ASF-Tune clean implementation

This directory is a compact implementation of the two method contributions in
**ASF-Tune: Adaptive Spatial-Frequency Tuning for Change Detection**:

1. **ASF-Adapter** jointly adapts bi-temporal features with a spatial branch,
   low-frequency style alignment, high-frequency detail refinement, and a
   content-aware router.
2. **TASC** adds hard-aware visual consistency/repulsion and text-anchored
   InfoNCE supervision during SCD training. It adds no inference-time text
   encoder or loss computation.

FastSAM is retained as the reference feature backbone, but it is deliberately
isolated behind a small paired-encoder contract. A replacement backbone only
needs to return two shallow-to-deep feature lists and expose `out_channels`.

## Project layout

```text
asf_tune/
  models/asf_adapter.py  # core ASF-Adapter
  models/fastsam.py      # frozen FastSAM + layer-wise adapter insertion
  models/decoders.py     # lightweight BCD/SCD FPN heads
  models/model.py        # unified task model
  tasc.py                # core TASC module
  text_anchors.py        # training-only RemoteCLIP anchor extraction
  data.py                # shared BCD/SCD dataset and augmentation
  losses.py              # task losses
  metrics.py             # BCD/SCD metrics
train.py                 # unified training entry point
evaluate.py              # text-free evaluation entry point
configs/                 # example experiment configurations
tests/test_core.py       # dependency-light core tests
```

## Data layout

Binary change detection:

```text
DATA_ROOT/{train,val,test}/
  A/
  B/
  label/
```

Semantic change detection:

```text
DATA_ROOT/{train,val,test}/
  t1/
  t2/
  label1/
  label2/
  change/
```

Matching files in a split must have the same filename. Binary change masks use
0 and 255. SCD semantic class 0 is reserved for unchanged/background, while
text anchors correspond to class IDs 1 through K by default.

## Setup and use

```bash
python -m pip install -r requirements.txt
python -m unittest tests.test_core
```

Edit the paths in one of the YAML files, then run:

```bash
python train.py --config configs/levir_bcd.yaml
python train.py --config configs/second_scd.yaml
python evaluate.py --config configs/second_scd.yaml \
  --checkpoint outputs/second_scd/best.pt --split test
```

RemoteCLIP is loaded only once to construct the SCD text-anchor tensor. The
text encoder is discarded afterward and is not part of `ASFTune.forward()`.

## Intentional cleanup from the research snapshot

- The low-frequency mixing coefficient is content-dependent and channel-wise,
  matching the paper rather than using one global scalar.
- Hard unchanged pixels are selected by lowest temporal cosine similarity,
  not sampled randomly.
- Text alignment uses temperature-scaled multi-class InfoNCE.
- BCD directly applies an FPN to absolute multi-scale feature differences.
- The FastSAM weights and running statistics stay frozen.
- BCD and SCD share one dataset implementation and one training entry point.
- Old BiSRNet, X3D/captioning, CRF, duplicate transforms, hard-coded paths,
  commented experiments, and cached bytecode are intentionally excluded.

Pretrained FastSAM and RemoteCLIP weights are not stored in this directory.

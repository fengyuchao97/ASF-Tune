import unittest

import torch
from torch import nn

from asf_tune.models.asf_adapter import ASFAdapter
from asf_tune.models.model import ASFTune
from asf_tune.tasc import TASC


class DummyPairedEncoder(nn.Module):
    out_channels = [8, 16]

    def __init__(self) -> None:
        super().__init__()
        self.stage1 = nn.Conv2d(3, 8, 3, padding=1)
        self.stage2 = nn.Conv2d(8, 16, 3, stride=2, padding=1)
        self.adapter1 = ASFAdapter(8, cutoff=0.25)
        self.adapter2 = ASFAdapter(16, cutoff=0.25)

    def forward(self, image_t1, image_t2):
        t1, t2 = self.stage1(image_t1), self.stage1(image_t2)
        t1, t2 = self.adapter1(t1, t2)
        features_t1, features_t2 = [t1], [t2]
        t1, t2 = self.stage2(t1), self.stage2(t2)
        t1, t2 = self.adapter2(t1, t2)
        return features_t1 + [t1], features_t2 + [t2]


class CoreTests(unittest.TestCase):
    def test_asf_adapter_shape_and_gradient(self):
        adapter = ASFAdapter(12, cutoff=0.25)
        t1 = torch.randn(2, 12, 15, 17, requires_grad=True)
        t2 = torch.randn(2, 12, 15, 17, requires_grad=True)
        out_t1, out_t2 = adapter(t1, t2)
        self.assertEqual(out_t1.shape, t1.shape)
        self.assertEqual(out_t2.shape, t2.shape)
        (out_t1.mean() + out_t2.mean()).backward()
        self.assertIsNotNone(adapter.scale.grad)
        self.assertTrue(torch.isfinite(out_t1).all())

    def test_tasc_components_and_gradient(self):
        loss_module = TASC(visual_dim=8, text_dim=6, label_offset=1)
        feature_t1 = torch.randn(2, 8, 8, 8, requires_grad=True)
        feature_t2 = torch.randn(2, 8, 8, 8, requires_grad=True)
        anchors = torch.randn(3, 6)
        label_t1 = torch.ones(2, 16, 16, dtype=torch.long)
        label_t2 = label_t1.clone()
        label_t2[:, :8] = 2
        change = torch.zeros(2, 16, 16)
        change[:, :8] = 1
        losses = loss_module(
            feature_t1, feature_t2, anchors, label_t1, label_t2, change
        )
        self.assertEqual(
            set(losses), {"total", "consistency", "repulsion", "anchor"}
        )
        losses["total"].backward()
        self.assertIsNotNone(loss_module.projector.weight.grad)

    def test_unified_model_bcd_and_scd_outputs(self):
        images = (torch.randn(2, 3, 32, 32), torch.randn(2, 3, 32, 32))
        bcd = ASFTune(DummyPairedEncoder(), task="bcd", embed_dim=8)
        bcd_output = bcd(*images)
        self.assertEqual(bcd_output["change_logits"].shape, (2, 1, 32, 32))

        scd = ASFTune(
            DummyPairedEncoder(), task="scd", num_semantic_classes=4,
            embed_dim=8, text_dim=6
        )
        scd_output = scd(*images)
        self.assertEqual(scd_output["semantic_t1_logits"].shape, (2, 4, 32, 32))
        self.assertEqual(scd_output["semantic_t2_logits"].shape, (2, 4, 32, 32))


if __name__ == "__main__":
    unittest.main()

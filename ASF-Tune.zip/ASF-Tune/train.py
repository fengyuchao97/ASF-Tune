from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import torch

from asf_tune.losses import bce_dice_loss, semantic_loss
from asf_tune.metrics import BinaryMeter, SemanticChangeMeter
from asf_tune.runtime import build_loader, build_model, load_config, move_batch
from asf_tune.text_anchors import build_text_anchors


def make_scheduler(
    optimizer: torch.optim.Optimizer, total_steps: int, warmup_steps: int
) -> torch.optim.lr_scheduler.LambdaLR:
    def multiplier(step: int) -> float:
        if step < warmup_steps:
            return float(step + 1) / max(1, warmup_steps)
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        return 0.5 * (1.0 + math.cos(math.pi * min(progress, 1.0)))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, multiplier)


def compute_loss(
    model,
    output: dict,
    batch: dict,
    text_anchors: torch.Tensor | None,
) -> tuple[torch.Tensor, dict[str, float]]:
    change = batch["change"][:, None]
    change_loss = bce_dice_loss(output["change_logits"], change)
    losses = {"change": change_loss}
    total = change_loss
    if model.task == "scd":
        semantic = semantic_loss(
            output["semantic_t1_logits"],
            output["semantic_t2_logits"],
            batch["label_t1"],
            batch["label_t2"],
            batch["change"],
        )
        if text_anchors is None:
            raise RuntimeError("SCD training requires text anchors")
        tasc = model.tasc_loss(
            output,
            text_anchors,
            batch["label_t1"],
            batch["label_t2"],
            batch["change"],
        )
        losses.update({"semantic": semantic, **{f"tasc_{k}": v for k, v in tasc.items()}})
        total = total + semantic + tasc["total"]
    return total, {name: value.detach().item() for name, value in losses.items()}


@torch.no_grad()
def validate(model, loader, device: torch.device) -> dict[str, float]:
    model.eval()
    binary = BinaryMeter()
    semantic = SemanticChangeMeter(model.semantic_t1.fpn.classifier.out_channels) if model.task == "scd" else None
    for batch in loader:
        batch = move_batch(batch, device)
        output = model(batch["image_t1"], batch["image_t2"])
        binary.update(output["change_logits"][:, 0], batch["change"])
        if semantic is not None:
            change_prediction = (output["change_logits"].sigmoid()[:, 0] > 0.5).long()
            prediction_t1 = output["semantic_t1_logits"].argmax(dim=1) * change_prediction
            prediction_t2 = output["semantic_t2_logits"].argmax(dim=1) * change_prediction
            semantic.update(prediction_t1, batch["label_t1"] * batch["change"].long())
            semantic.update(prediction_t2, batch["label_t2"] * batch["change"].long())
    scores = {f"BCD/{key}": value for key, value in binary.scores().items()}
    if semantic is not None:
        scores.update({f"SCD/{key}": value for key, value in semantic.scores().items()})
    return scores


def train(config: dict, resume: str | None = None) -> None:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(config).to(device)
    train_loader = build_loader(config, "train", training=True)
    val_loader = build_loader(config, config.get("val_split", "val"), training=False)
    anchors = None
    if config["task"] == "scd":
        anchors = build_text_anchors(
            config["class_names"],
            config["remoteclip_weights"],
            model_name=config.get("text_model", "ViT-B-32"),
            device=device,
        ).to(device)

    optimizer = torch.optim.AdamW(
        (parameter for parameter in model.parameters() if parameter.requires_grad),
        lr=config.get("learning_rate", 3e-4),
        weight_decay=config.get("weight_decay", 0.05),
    )
    epochs = config.get("epochs", 50 if config["task"] == "scd" else 100)
    scheduler = make_scheduler(
        optimizer, epochs * len(train_loader), config.get("warmup_steps", 1000)
    )
    start_epoch, best_score = 0, -1.0
    if resume:
        checkpoint = torch.load(resume, map_location=device)
        model.load_state_dict(checkpoint["model"])
        optimizer.load_state_dict(checkpoint["optimizer"])
        scheduler.load_state_dict(checkpoint["scheduler"])
        start_epoch = checkpoint["epoch"]
        best_score = checkpoint.get("best_score", -1.0)

    output_dir = Path(config.get("output_dir", "outputs/default"))
    output_dir.mkdir(parents=True, exist_ok=True)
    trainable = sum(parameter.numel() for parameter in model.parameters() if parameter.requires_grad)
    total = sum(parameter.numel() for parameter in model.parameters())
    print(f"device={device} trainable={trainable / 1e6:.2f}M total={total / 1e6:.2f}M")

    for epoch in range(start_epoch, epochs):
        model.train()
        running: dict[str, float] = {}
        for batch in train_loader:
            batch = move_batch(batch, device)
            output = model(batch["image_t1"], batch["image_t2"])
            loss, parts = compute_loss(model, output, batch, anchors)
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            optimizer.step()
            scheduler.step()
            for name, value in parts.items():
                running[name] = running.get(name, 0.0) + value

        scores = validate(model, val_loader, device)
        average_losses = {name: value / len(train_loader) for name, value in running.items()}
        print(json.dumps({"epoch": epoch + 1, **average_losses, **scores}, sort_keys=True))
        selection_score = scores["SCD/F1"] if model.task == "scd" else scores["BCD/F1"]
        checkpoint = {
            "epoch": epoch + 1,
            "model": model.state_dict(),
            "optimizer": optimizer.state_dict(),
            "scheduler": scheduler.state_dict(),
            "best_score": max(best_score, selection_score),
            "config": config,
        }
        torch.save(checkpoint, output_dir / "last.pt")
        if selection_score > best_score:
            best_score = selection_score
            torch.save(checkpoint, output_dir / "best.pt")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train ASF-Tune")
    parser.add_argument("--config", required=True)
    parser.add_argument("--resume")
    arguments = parser.parse_args()
    train(load_config(arguments.config), arguments.resume)

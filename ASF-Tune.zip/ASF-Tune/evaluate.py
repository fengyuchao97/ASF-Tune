from __future__ import annotations

import argparse
import json

import torch

from asf_tune.runtime import build_loader, build_model, load_config
from train import validate


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate ASF-Tune")
    parser.add_argument("--config", required=True)
    parser.add_argument("--checkpoint", required=True)
    parser.add_argument("--split", default="test")
    arguments = parser.parse_args()

    config = load_config(arguments.config)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = build_model(config).to(device)
    checkpoint = torch.load(arguments.checkpoint, map_location=device)
    model.load_state_dict(checkpoint.get("model", checkpoint))
    loader = build_loader(config, arguments.split, training=False)
    print(json.dumps(validate(model, loader, device), indent=2, sort_keys=True))

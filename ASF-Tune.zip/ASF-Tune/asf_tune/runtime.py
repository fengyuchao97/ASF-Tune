from __future__ import annotations

from pathlib import Path

import torch
import yaml
from torch.utils.data import DataLoader

from .data import ChangeDetectionDataset, JointTransform
from .models.fastsam import FastSAMPairedEncoder
from .models.model import ASFTune


def load_config(path: str | Path) -> dict:
    with Path(path).open("r", encoding="utf-8") as stream:
        config = yaml.safe_load(stream)
    required = {"task", "data_root", "fastsam_weights", "num_classes"}
    missing = required - config.keys()
    if missing:
        raise KeyError(f"missing config keys: {sorted(missing)}")
    return config


def build_model(config: dict) -> ASFTune:
    encoder = FastSAMPairedEncoder(
        weights=config["fastsam_weights"],
        adapter_layers=config.get("adapter_layers", (1, 2, 3, 4, 5, 6, 7, 8, 9)),
        feature_layers=config.get("feature_layers", (2, 4, 6, 9)),
        cutoffs=config.get("cutoffs"),
    )
    return ASFTune(
        encoder=encoder,
        task=config["task"],
        num_semantic_classes=config["num_classes"],
        embed_dim=config.get("embed_dim", 256),
        text_dim=config.get("text_dim", 512),
        tasc_options=config.get("tasc", {}),
    )


def build_loader(config: dict, split: str, training: bool) -> DataLoader:
    size = config.get("image_size", 256)
    transform = JointTransform(
        size=(size, size),
        training=training,
        mean=config.get("mean", (0.5, 0.5, 0.5)),
        std=config.get("std", (0.5, 0.5, 0.5)),
        scale_range=tuple(config.get("scale_range", (0.8, 1.2))),
        blur_probability=config.get("blur_probability", 0.2),
    )
    dataset = ChangeDetectionDataset(
        config["data_root"], split, config["task"], transform
    )
    return DataLoader(
        dataset,
        batch_size=config.get("batch_size", 8),
        shuffle=training,
        num_workers=config.get("num_workers", 4),
        pin_memory=torch.cuda.is_available(),
        drop_last=training,
    )


def move_batch(batch: dict, device: torch.device) -> dict:
    return {
        key: value.to(device, non_blocking=True) if torch.is_tensor(value) else value
        for key, value in batch.items()
    }

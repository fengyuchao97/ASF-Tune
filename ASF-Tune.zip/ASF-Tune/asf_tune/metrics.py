from __future__ import annotations

import math

import numpy as np
import torch
from torch import Tensor


def _safe_divide(numerator: float, denominator: float) -> float:
    return numerator / denominator if denominator else 0.0


class BinaryMeter:
    def __init__(self) -> None:
        self.confusion = np.zeros((2, 2), dtype=np.float64)

    def update(self, logits: Tensor, target: Tensor) -> None:
        prediction = (logits.sigmoid() > 0.5).long().cpu().numpy().reshape(-1)
        target_np = target.long().cpu().numpy().reshape(-1)
        self.confusion += np.bincount(
            2 * target_np + prediction, minlength=4
        ).reshape(2, 2)

    def scores(self) -> dict[str, float]:
        tn, fp, fn, tp = self.confusion.ravel()
        precision = _safe_divide(tp, tp + fp)
        recall = _safe_divide(tp, tp + fn)
        return {
            "F1": _safe_divide(2 * precision * recall, precision + recall),
            "IoU": _safe_divide(tp, tp + fp + fn),
            "OA": _safe_divide(tp + tn, self.confusion.sum()),
            "precision": precision,
            "recall": recall,
        }


def _kappa(confusion: np.ndarray) -> float:
    total = confusion.sum()
    if total == 0:
        return 0.0
    observed = np.diag(confusion).sum() / total
    expected = confusion.sum(1) @ confusion.sum(0) / (total * total)
    return _safe_divide(observed - expected, 1.0 - expected)


class SemanticChangeMeter:
    """SCD metrics including Fscd, mIoU, OA, and SeK."""

    def __init__(self, num_classes: int) -> None:
        self.num_classes = num_classes
        self.confusion = np.zeros((num_classes, num_classes), dtype=np.float64)

    def update(self, prediction: Tensor, target: Tensor) -> None:
        prediction = prediction.long().cpu().numpy().reshape(-1)
        target = target.long().cpu().numpy().reshape(-1)
        valid = (target >= 0) & (target < self.num_classes)
        self.confusion += np.bincount(
            self.num_classes * target[valid] + prediction[valid],
            minlength=self.num_classes**2,
        ).reshape(self.num_classes, self.num_classes)

    def scores(self) -> dict[str, float]:
        confusion = self.confusion
        union = confusion.sum(1) + confusion.sum(0) - np.diag(confusion)
        class_iou = np.divide(
            np.diag(confusion), union, out=np.zeros_like(union), where=union > 0
        )
        foreground = confusion[1:, 1:]
        binary = np.array(
            [
                [confusion[0, 0], confusion[0, 1:].sum()],
                [confusion[1:, 0].sum(), foreground.sum()],
            ]
        )
        binary_union = binary.sum(1) + binary.sum(0) - np.diag(binary)
        binary_iou = np.divide(
            np.diag(binary), binary_union, out=np.zeros(2), where=binary_union > 0
        )
        confusion_without_tn = confusion.copy()
        confusion_without_tn[0, 0] = 0
        sek = _kappa(confusion_without_tn) * math.exp(binary_iou[1]) / math.e
        semantic_tp = np.diag(foreground).sum()
        predicted_change = confusion[:, 1:].sum()
        target_change = confusion[1:, :].sum()
        precision = _safe_divide(semantic_tp, predicted_change)
        recall = _safe_divide(semantic_tp, target_change)
        return {
            "F1": _safe_divide(2 * precision * recall, precision + recall),
            "mIoU": float(class_iou.mean()),
            "binary_mIoU": float(binary_iou.mean()),
            "OA": _safe_divide(np.diag(confusion).sum(), confusion.sum()),
            "SeK": sek,
        }

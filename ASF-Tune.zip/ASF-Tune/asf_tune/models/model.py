"""Unified BCD/SCD model assembled from replaceable components."""

from __future__ import annotations

import torch.nn.functional as F
from torch import Tensor, nn

from ..tasc import TASC
from .decoders import BinaryChangeDecoder, SemanticDecoder


class ASFTune(nn.Module):
    def __init__(
        self,
        encoder: nn.Module,
        task: str,
        num_semantic_classes: int = 7,
        embed_dim: int = 256,
        text_dim: int = 512,
        tasc_options: dict | None = None,
    ) -> None:
        super().__init__()
        if task not in {"bcd", "scd"}:
            raise ValueError("task must be 'bcd' or 'scd'")
        if not hasattr(encoder, "out_channels"):
            raise TypeError("encoder must expose an out_channels sequence")
        self.task = task
        self.encoder = encoder
        self.change_decoder = BinaryChangeDecoder(encoder.out_channels, embed_dim)
        if task == "scd":
            self.semantic_t1 = SemanticDecoder(
                encoder.out_channels, num_semantic_classes, embed_dim
            )
            self.semantic_t2 = SemanticDecoder(
                encoder.out_channels, num_semantic_classes, embed_dim
            )
            self.tasc = TASC(embed_dim, text_dim, **(tasc_options or {}))

    def forward(self, image_t1: Tensor, image_t2: Tensor) -> dict[str, Tensor]:
        output_size = image_t1.shape[-2:]
        features_t1, features_t2 = self.encoder(image_t1, image_t2)
        change_logits, _ = self.change_decoder(features_t1, features_t2)
        output = {
            "change_logits": F.interpolate(
                change_logits, output_size, mode="bilinear", align_corners=False
            )
        }
        if self.task == "scd":
            semantic_t1, semantic_feature_t1 = self.semantic_t1(features_t1)
            semantic_t2, semantic_feature_t2 = self.semantic_t2(features_t2)
            output.update(
                {
                    "semantic_t1_logits": F.interpolate(
                        semantic_t1, output_size, mode="bilinear", align_corners=False
                    ),
                    "semantic_t2_logits": F.interpolate(
                        semantic_t2, output_size, mode="bilinear", align_corners=False
                    ),
                    "semantic_t1_features": semantic_feature_t1,
                    "semantic_t2_features": semantic_feature_t2,
                }
            )
        return output

    def tasc_loss(
        self,
        output: dict[str, Tensor],
        text_anchors: Tensor,
        label_t1: Tensor,
        label_t2: Tensor,
        change_mask: Tensor,
    ) -> dict[str, Tensor]:
        if self.task != "scd":
            raise RuntimeError("TASC is only defined for semantic change detection")
        return self.tasc(
            output["semantic_t1_features"],
            output["semantic_t2_features"],
            text_anchors,
            label_t1,
            label_t2,
            change_mask,
        )

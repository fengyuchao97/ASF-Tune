"""Lightweight task-oriented FPN decoders."""

from __future__ import annotations

from typing import Sequence

import torch
import torch.nn.functional as F
from torch import Tensor, nn


class ConvNormAct(nn.Sequential):
    def __init__(self, in_channels: int, out_channels: int) -> None:
        super().__init__(
            nn.Conv2d(in_channels, out_channels, 1, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.GELU(),
        )


class FPNHead(nn.Module):
    """Project and aggregate a shallow-to-deep feature pyramid."""

    def __init__(
        self, in_channels: Sequence[int], embed_dim: int, out_channels: int
    ) -> None:
        super().__init__()
        self.projections = nn.ModuleList(
            [ConvNormAct(channels, embed_dim) for channels in in_channels]
        )
        self.refine = nn.ModuleList(
            [
                nn.Sequential(
                    nn.Conv2d(embed_dim, embed_dim, 3, padding=1, bias=False),
                    nn.BatchNorm2d(embed_dim),
                    nn.GELU(),
                )
                for _ in range(len(in_channels) - 1)
            ]
        )
        self.classifier = nn.Conv2d(embed_dim, out_channels, 1)

    def forward(self, features: Sequence[Tensor]) -> tuple[Tensor, Tensor]:
        if len(features) != len(self.projections):
            raise ValueError("feature count does not match decoder configuration")
        projected = [layer(feature) for layer, feature in zip(self.projections, features)]
        fused = projected[-1]
        for level in range(len(projected) - 2, -1, -1):
            fused = F.interpolate(
                fused, size=projected[level].shape[-2:], mode="bilinear", align_corners=False
            )
            fused = self.refine[level](fused + projected[level])
        return self.classifier(fused), fused


class BinaryChangeDecoder(nn.Module):
    def __init__(self, in_channels: Sequence[int], embed_dim: int = 256) -> None:
        super().__init__()
        self.fpn = FPNHead(in_channels, embed_dim, 1)

    def forward(
        self, features_t1: Sequence[Tensor], features_t2: Sequence[Tensor]
    ) -> tuple[Tensor, Tensor]:
        differences = [
            torch.abs(feature_t1 - feature_t2)
            for feature_t1, feature_t2 in zip(features_t1, features_t2)
        ]
        return self.fpn(differences)


class SemanticDecoder(nn.Module):
    def __init__(
        self, in_channels: Sequence[int], num_classes: int, embed_dim: int = 256
    ) -> None:
        super().__init__()
        self.fpn = FPNHead(in_channels, embed_dim, num_classes)

    def forward(self, features: Sequence[Tensor]) -> tuple[Tensor, Tensor]:
        return self.fpn(features)

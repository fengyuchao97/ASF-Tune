"""FastSAM feature encoder with layer-wise ASF-Adapter insertion."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

import torch
from torch import Tensor, nn

from .asf_adapter import ASFAdapter


class FastSAMPairedEncoder(nn.Module):
    """Run a shared frozen FastSAM backbone on a bi-temporal image pair.

    FastSAM is intentionally isolated in this file. A different VFM only needs
    to implement the same ``forward(t1, t2) -> (features_t1, features_t2)``
    contract and expose ``out_channels``.
    """

    def __init__(
        self,
        weights: str | Path,
        adapter_layers: Sequence[int] = (1, 2, 3, 4, 5, 6, 7, 8, 9),
        feature_layers: Sequence[int] = (2, 4, 6, 9),
        cutoffs: Sequence[float] | None = None,
        probe_size: int = 64,
    ) -> None:
        super().__init__()
        try:
            from ultralytics import YOLO
        except ImportError as error:
            raise ImportError(
                "FastSAM support requires `pip install ultralytics`."
            ) from error

        weights = Path(weights)
        if not weights.is_file():
            raise FileNotFoundError(f"FastSAM weights not found: {weights}")
        self.adapter_layers = tuple(sorted(set(adapter_layers)))
        self.feature_layers = tuple(feature_layers)
        if not self.adapter_layers or not self.feature_layers:
            raise ValueError("adapter_layers and feature_layers cannot be empty")
        self.stop_layer = max(max(self.adapter_layers), max(self.feature_layers))

        fastsam = YOLO(str(weights)).model
        self.backbone_layers = fastsam.model
        for parameter in self.backbone_layers.parameters():
            parameter.requires_grad = False
        self.backbone_layers.eval()

        layer_channels = self._probe_channels(probe_size)
        if cutoffs is None:
            cutoffs = tuple(self._default_cutoff(index) for index in self.adapter_layers)
        if len(cutoffs) != len(self.adapter_layers):
            raise ValueError("cutoffs must match adapter_layers")
        self.adapters = nn.ModuleDict(
            {
                str(index): ASFAdapter(layer_channels[index], cutoff=cutoff)
                for index, cutoff in zip(self.adapter_layers, cutoffs)
            }
        )
        self.out_channels = [layer_channels[index] for index in self.feature_layers]

    @staticmethod
    def _default_cutoff(layer_index: int) -> float:
        if layer_index <= 3:
            return 0.05
        if layer_index <= 6:
            return 0.20
        return 0.40

    def _probe_channels(self, size: int) -> dict[int, int]:
        device = next(self.backbone_layers.parameters()).device
        x = torch.zeros(1, 3, size, size, device=device)
        channels: dict[int, int] = {}
        with torch.no_grad():
            for index, layer in enumerate(self.backbone_layers):
                x = layer(x)
                if index in set(self.adapter_layers) | set(self.feature_layers):
                    channels[index] = x.shape[1]
                if index == self.stop_layer:
                    break
        return channels

    def train(self, mode: bool = True) -> "FastSAMPairedEncoder":
        super().train(mode)
        # Keep weights and running statistics of the VFM fixed.
        self.backbone_layers.eval()
        self.adapters.train(mode)
        return self

    def forward(self, image_t1: Tensor, image_t2: Tensor) -> tuple[list[Tensor], list[Tensor]]:
        features_t1: list[Tensor] = []
        features_t2: list[Tensor] = []
        x_t1, x_t2 = image_t1.float(), image_t2.float()
        for index, layer in enumerate(self.backbone_layers):
            x_t1 = layer(x_t1)
            x_t2 = layer(x_t2)
            if str(index) in self.adapters:
                x_t1, x_t2 = self.adapters[str(index)](x_t1, x_t2)
            if index in self.feature_layers:
                features_t1.append(x_t1)
                features_t2.append(x_t2)
            if index == self.stop_layer:
                break
        return features_t1, features_t2

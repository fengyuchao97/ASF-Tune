"""Adaptive Spatial-Frequency Adapter.

This module follows Section 3.2 of the paper.  It has three feature
increments (spatial, low frequency, and high frequency), a content-aware
router, and a small residual scale.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor, nn


class SpatialBranch(nn.Module):
    """Lightweight local and multi-scale spatial perception."""

    def __init__(self, channels: int) -> None:
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels),
            nn.GELU(),
            nn.Conv2d(channels, channels, 3, padding=1, groups=channels),
        )

    def forward(self, x: Tensor) -> Tensor:
        return self.block(x)


class HighFrequencyRefinement(nn.Module):
    """Spatial gate computed from channel-average and channel-max maps."""

    def __init__(self, kernel_size: int = 3) -> None:
        super().__init__()
        if kernel_size % 2 == 0:
            raise ValueError("kernel_size must be odd")
        self.gate = nn.Sequential(
            nn.Conv2d(2, 1, kernel_size, padding=kernel_size // 2, bias=False),
            nn.Sigmoid(),
        )

    def forward(self, x: Tensor) -> Tensor:
        summary = torch.cat(
            [x.mean(dim=1, keepdim=True), x.amax(dim=1, keepdim=True)], dim=1
        )
        return x * self.gate(summary)


class LowFrequencyStyleAlignment(nn.Module):
    """Content-adaptive, channel-wise cross-temporal style interpolation."""

    def __init__(self, channels: int, reduction: int = 4) -> None:
        super().__init__()
        hidden = max(channels // reduction, 16)
        self.style_weight = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            nn.Linear(channels * 2, hidden),
            nn.GELU(),
            nn.Linear(hidden, channels),
            nn.Sigmoid(),
        )
        self.projection = nn.Conv2d(channels, channels, 1)

    def forward(self, low_t1: Tensor, low_t2: Tensor) -> tuple[Tensor, Tensor]:
        alpha = self.style_weight(torch.cat([low_t1, low_t2], dim=1))
        alpha = alpha[:, :, None, None]
        aligned_t1 = alpha * low_t1 + (1.0 - alpha) * low_t2
        aligned_t2 = (1.0 - alpha) * low_t1 + alpha * low_t2
        return self.projection(aligned_t1), self.projection(aligned_t2)


class ContentRouter(nn.Module):
    def __init__(self, channels: int, branches: int = 3) -> None:
        super().__init__()
        hidden = max(channels // 4, 16)
        self.norm = nn.LayerNorm(channels)
        self.mlp = nn.Sequential(
            nn.Linear(channels, hidden),
            nn.GELU(),
            nn.Linear(hidden, branches),
        )

    def forward(self, x: Tensor) -> Tensor:
        context = self.norm(x.mean(dim=(-2, -1)))
        return self.mlp(context).softmax(dim=-1)[:, :, None, None, None]


class ASFAdapter(nn.Module):
    """Jointly adapt a pair of bi-temporal feature maps.

    Args:
        channels: Channel count of the insertion layer.
        cutoff: Side length ratio of the centered low-frequency square.
        high_frequency_kernel: Kernel used by the high-frequency gate.
        residual_scale: Initial value of the learnable residual scale.
    """

    def __init__(
        self,
        channels: int,
        cutoff: float = 0.25,
        high_frequency_kernel: int = 3,
        residual_scale: float = 1e-3,
    ) -> None:
        super().__init__()
        if not 0.0 < cutoff <= 1.0:
            raise ValueError("cutoff must be in (0, 1]")
        self.channels = channels
        self.cutoff = cutoff
        self.spatial = SpatialBranch(channels)
        self.low_frequency = LowFrequencyStyleAlignment(channels)
        self.high_frequency = HighFrequencyRefinement(high_frequency_kernel)
        self.router = ContentRouter(channels)
        self.scale = nn.Parameter(torch.tensor(float(residual_scale)))
        self.reset_parameters()

    def reset_parameters(self) -> None:
        for module in self.modules():
            if isinstance(module, (nn.Conv2d, nn.Linear)):
                nn.init.kaiming_uniform_(module.weight, a=math.sqrt(5))
                if module.bias is not None:
                    nn.init.zeros_(module.bias)

    def _frequency_split(self, x: Tensor) -> tuple[Tensor, Tensor]:
        spectrum = torch.fft.fftshift(
            torch.fft.fft2(x.float(), norm="ortho"), dim=(-2, -1)
        )
        height, width = x.shape[-2:]
        half_h = max(1, round(height * self.cutoff / 2))
        half_w = max(1, round(width * self.cutoff / 2))
        center_h, center_w = height // 2, width // 2
        start_h, end_h = max(0, center_h - half_h), min(height, center_h + half_h)
        start_w, end_w = max(0, center_w - half_w), min(width, center_w + half_w)
        mask = torch.zeros(
            (1, 1, height, width), device=x.device, dtype=spectrum.real.dtype
        )
        mask[..., start_h:end_h, start_w:end_w] = 1.0
        low_spectrum = spectrum * mask
        high_spectrum = spectrum * (1.0 - mask)
        low = torch.fft.ifft2(
            torch.fft.ifftshift(low_spectrum, dim=(-2, -1)), norm="ortho"
        ).real
        high = torch.fft.ifft2(
            torch.fft.ifftshift(high_spectrum, dim=(-2, -1)), norm="ortho"
        ).real
        return low.to(x.dtype), high.to(x.dtype)

    def _fuse(self, source: Tensor, branches: list[Tensor]) -> Tensor:
        weights = self.router(source)
        stacked = torch.stack(branches, dim=1)
        return source + self.scale * (weights * stacked).sum(dim=1)

    def forward(self, feature_t1: Tensor, feature_t2: Tensor) -> tuple[Tensor, Tensor]:
        if feature_t1.shape != feature_t2.shape:
            raise ValueError("bi-temporal features must have identical shapes")
        if feature_t1.ndim != 4 or feature_t1.shape[1] != self.channels:
            raise ValueError(
                f"expected [B, {self.channels}, H, W], got {tuple(feature_t1.shape)}"
            )

        low_t1, high_t1 = self._frequency_split(feature_t1)
        low_t2, high_t2 = self._frequency_split(feature_t2)
        low_t1, low_t2 = self.low_frequency(low_t1, low_t2)

        branches_t1 = [
            self.spatial(feature_t1),
            low_t1,
            self.high_frequency(high_t1),
        ]
        branches_t2 = [
            self.spatial(feature_t2),
            low_t2,
            self.high_frequency(high_t2),
        ]
        return (
            self._fuse(feature_t1, branches_t1),
            self._fuse(feature_t2, branches_t2),
        )

"""Training-only RemoteCLIP text anchor construction."""

from __future__ import annotations

from pathlib import Path
from typing import Sequence

import torch
import torch.nn.functional as F
from torch import Tensor


DEFAULT_TEMPLATES = (
    "a satellite image of {}.",
    "an aerial view of {}.",
    "a drone view of {}.",
    "a remote sensing image of {}.",
    "{}.",
)


@torch.no_grad()
def build_text_anchors(
    class_names: Sequence[str],
    weights: str | Path,
    model_name: str = "ViT-B-32",
    templates: Sequence[str] = DEFAULT_TEMPLATES,
    device: str | torch.device = "cpu",
) -> Tensor:
    """Return one normalized anchor per semantic category."""
    try:
        import open_clip
    except ImportError as error:
        raise ImportError("Text anchors require `pip install open_clip_torch`.") from error

    weights = Path(weights)
    if not weights.is_file():
        raise FileNotFoundError(f"RemoteCLIP weights not found: {weights}")
    model, _, _ = open_clip.create_model_and_transforms(model_name, pretrained=None)
    checkpoint = torch.load(weights, map_location="cpu")
    state_dict = checkpoint.get("state_dict", checkpoint) if isinstance(checkpoint, dict) else checkpoint
    model.load_state_dict(state_dict, strict=True)
    model = model.to(device).eval()
    tokenizer = open_clip.get_tokenizer(model_name)

    anchors = []
    for class_name in class_names:
        tokens = tokenizer([template.format(class_name) for template in templates]).to(device)
        embeddings = F.normalize(model.encode_text(tokens).float(), dim=-1)
        anchors.append(F.normalize(embeddings.mean(dim=0), dim=0))
    return torch.stack(anchors).cpu()

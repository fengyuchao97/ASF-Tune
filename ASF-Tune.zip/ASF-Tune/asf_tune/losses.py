from __future__ import annotations

import torch
import torch.nn.functional as F
from torch import Tensor


def soft_dice_loss(logits: Tensor, target: Tensor, eps: float = 1e-6) -> Tensor:
    probability = logits.sigmoid()
    target = target.float()
    dims = tuple(range(1, probability.ndim))
    intersection = (probability * target).sum(dim=dims)
    denominator = probability.sum(dim=dims) + target.sum(dim=dims)
    return (1.0 - (2.0 * intersection + eps) / (denominator + eps)).mean()


def bce_dice_loss(logits: Tensor, target: Tensor) -> Tensor:
    return F.binary_cross_entropy_with_logits(logits, target.float()) + soft_dice_loss(
        logits, target
    )


def semantic_loss(
    logits_t1: Tensor,
    logits_t2: Tensor,
    label_t1: Tensor,
    label_t2: Tensor,
    change_mask: Tensor,
    ignore_index: int = 0,
) -> Tensor:
    # Standard SCD labels use class 0 for unchanged/background. Masking here
    # keeps semantic supervision focused on genuinely changed pixels.
    masked_t1 = label_t1 * change_mask.long()
    masked_t2 = label_t2 * change_mask.long()

    def cross_entropy_or_zero(logits: Tensor, target: Tensor) -> Tensor:
        if not (target != ignore_index).any():
            return logits.sum() * 0.0
        return F.cross_entropy(logits, target, ignore_index=ignore_index)

    return 0.5 * (
        cross_entropy_or_zero(logits_t1, masked_t1)
        + cross_entropy_or_zero(logits_t2, masked_t2)
    )

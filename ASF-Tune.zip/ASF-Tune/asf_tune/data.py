"""Shared dataset and augmentation code for BCD and SCD."""

from __future__ import annotations

import random
from pathlib import Path
from typing import Sequence

import numpy as np
import torch
from PIL import Image, ImageFilter
from torch import Tensor
from torch.utils.data import Dataset


class JointTransform:
    def __init__(
        self,
        size: tuple[int, int] = (256, 256),
        training: bool = False,
        mean: Sequence[float] = (0.5, 0.5, 0.5),
        std: Sequence[float] = (0.5, 0.5, 0.5),
        scale_range: tuple[float, float] = (0.8, 1.2),
        blur_probability: float = 0.2,
    ) -> None:
        self.size = size
        self.training = training
        self.mean = torch.tensor(mean)[:, None, None]
        self.std = torch.tensor(std)[:, None, None]
        self.scale_range = scale_range
        self.blur_probability = blur_probability

    @staticmethod
    def _flip(images: list[Image.Image], labels: list[Image.Image]) -> None:
        if random.random() < 0.5:
            for index in range(len(images)):
                images[index] = images[index].transpose(Image.Transpose.FLIP_LEFT_RIGHT)
            for index in range(len(labels)):
                labels[index] = labels[index].transpose(Image.Transpose.FLIP_LEFT_RIGHT)
        if random.random() < 0.5:
            for index in range(len(images)):
                images[index] = images[index].transpose(Image.Transpose.FLIP_TOP_BOTTOM)
            for index in range(len(labels)):
                labels[index] = labels[index].transpose(Image.Transpose.FLIP_TOP_BOTTOM)

    def _scale_crop(
        self, images: list[Image.Image], labels: list[Image.Image]
    ) -> tuple[list[Image.Image], list[Image.Image]]:
        target_w, target_h = self.size
        scale = random.uniform(*self.scale_range)
        scaled_w, scaled_h = max(1, round(target_w * scale)), max(1, round(target_h * scale))
        images = [image.resize((scaled_w, scaled_h), Image.Resampling.BILINEAR) for image in images]
        labels = [label.resize((scaled_w, scaled_h), Image.Resampling.NEAREST) for label in labels]
        crop_x = random.randint(0, scaled_w - target_w) if scaled_w > target_w else 0
        crop_y = random.randint(0, scaled_h - target_h) if scaled_h > target_h else 0
        paste_x = random.randint(0, target_w - scaled_w) if scaled_w < target_w else 0
        paste_y = random.randint(0, target_h - scaled_h) if scaled_h < target_h else 0

        def fit(image: Image.Image) -> Image.Image:
            source_left = crop_x if scaled_w > target_w else 0
            source_top = crop_y if scaled_h > target_h else 0
            source_right = source_left + min(scaled_w, target_w)
            source_bottom = source_top + min(scaled_h, target_h)
            image = image.crop((source_left, source_top, source_right, source_bottom))
            canvas = Image.new(image.mode, (target_w, target_h), 0)
            canvas.paste(image, (paste_x, paste_y))
            return canvas

        return ([fit(image) for image in images], [fit(label) for label in labels])

    def _image_tensor(self, image: Image.Image) -> Tensor:
        array = np.asarray(image, dtype=np.float32).copy() / 255.0
        tensor = torch.from_numpy(array).permute(2, 0, 1)
        return (tensor - self.mean) / self.std

    @staticmethod
    def _label_tensor(label: Image.Image) -> Tensor:
        return torch.from_numpy(np.asarray(label, dtype=np.int64).copy())

    def __call__(
        self,
        images: list[Image.Image],
        labels: list[Image.Image],
        swap_semantic_labels: bool,
    ) -> tuple[list[Tensor], list[Tensor]]:
        if self.training:
            images, labels = self._scale_crop(images, labels)
            self._flip(images, labels)
            if random.random() < 0.5:
                images[0], images[1] = images[1], images[0]
                if swap_semantic_labels:
                    labels[0], labels[1] = labels[1], labels[0]
            if random.random() < self.blur_probability:
                radius = random.uniform(0.1, 1.5)
                images = [image.filter(ImageFilter.GaussianBlur(radius)) for image in images]
        else:
            images = [image.resize(self.size, Image.Resampling.BILINEAR) for image in images]
            labels = [label.resize(self.size, Image.Resampling.NEAREST) for label in labels]
        return [self._image_tensor(image) for image in images], [self._label_tensor(label) for label in labels]


class ChangeDetectionDataset(Dataset):
    """Dataset for the conventional directory layouts used by RSCD benchmarks."""

    def __init__(
        self,
        root: str | Path,
        split: str,
        task: str,
        transform: JointTransform,
    ) -> None:
        if task not in {"bcd", "scd"}:
            raise ValueError("task must be 'bcd' or 'scd'")
        self.root = Path(root) / split
        self.task = task
        self.transform = transform
        label_folder = "label" if task == "bcd" else "label1"
        self.names = sorted(path.name for path in (self.root / label_folder).iterdir() if path.is_file())
        if not self.names:
            raise RuntimeError(f"no samples found in {self.root / label_folder}")

    def __len__(self) -> int:
        return len(self.names)

    def _open(self, folder: str, name: str, mode: str) -> Image.Image:
        path = self.root / folder / name
        if not path.is_file():
            raise FileNotFoundError(path)
        return Image.open(path).convert(mode)

    def __getitem__(self, index: int) -> dict[str, Tensor | str]:
        name = self.names[index]
        if self.task == "bcd":
            images = [self._open("A", name, "RGB"), self._open("B", name, "RGB")]
            labels = [self._open("label", name, "L")]
            images, labels = self.transform(images, labels, swap_semantic_labels=False)
            change = (labels[0] > 127).float()
            return {"image_t1": images[0], "image_t2": images[1], "change": change, "name": name}

        images = [self._open("t1", name, "RGB"), self._open("t2", name, "RGB")]
        labels = [
            self._open("label1", name, "L"),
            self._open("label2", name, "L"),
            self._open("change", name, "L"),
        ]
        images, labels = self.transform(images, labels, swap_semantic_labels=True)
        return {
            "image_t1": images[0],
            "image_t2": images[1],
            "label_t1": labels[0].long(),
            "label_t2": labels[1].long(),
            "change": (labels[2] > 127).float(),
            "name": name,
        }

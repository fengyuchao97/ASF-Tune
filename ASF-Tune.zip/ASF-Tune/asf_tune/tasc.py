"""Text-Anchored Semantic Contrastive loss from Section 3.3."""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import Tensor, nn


def _zero_like(x: Tensor) -> Tensor:
    return x.sum() * 0.0


class TASC(nn.Module):
    """Training-only semantic regularizer.

    The visual projector belongs to this module and is optimized jointly with
    the adapter and decoders. Text anchors are supplied by the training code,
    so neither the text encoder nor this loss is needed during inference.
    """

    def __init__(
        self,
        visual_dim: int,
        text_dim: int,
        hard_ratio: float = 0.10,
        margin: float = 0.70,
        temperature: float = 0.07,
        label_offset: int = 1,
        ignore_index: int = 255,
    ) -> None:
        super().__init__()
        if not 0.0 < hard_ratio <= 1.0:
            raise ValueError("hard_ratio must be in (0, 1]")
        self.projector = nn.Conv2d(visual_dim, text_dim, 1, bias=False)
        self.hard_ratio = hard_ratio
        self.margin = margin
        self.temperature = temperature
        self.label_offset = label_offset
        self.ignore_index = ignore_index

    @staticmethod
    def _resize_label(label: Tensor, size: tuple[int, int]) -> Tensor:
        return F.interpolate(label[:, None].float(), size=size, mode="nearest")[:, 0].long()

    def _hard_consistency(
        self, similarity: Tensor, unchanged: Tensor, valid: Tensor
    ) -> Tensor:
        losses: list[Tensor] = []
        for batch_index in range(similarity.shape[0]):
            values = similarity[batch_index][unchanged[batch_index] & valid[batch_index]]
            if values.numel() == 0:
                continue
            count = max(1, math.ceil(values.numel() * self.hard_ratio))
            hard_values = torch.topk(values, count, largest=False).values
            losses.append((1.0 - hard_values).mean())
        return torch.stack(losses).mean() if losses else _zero_like(similarity)

    def _anchor_alignment(
        self,
        projected: Tensor,
        anchors: Tensor,
        labels: Tensor,
        changed: Tensor,
        valid: Tensor,
    ) -> Tensor:
        features = projected.permute(0, 2, 3, 1)
        targets = labels - self.label_offset
        selected = (
            changed
            & valid
            & (targets >= 0)
            & (targets < anchors.shape[0])
        )
        if not selected.any():
            return _zero_like(projected)
        logits = features[selected] @ anchors.T / self.temperature
        return F.cross_entropy(logits, targets[selected])

    def forward(
        self,
        feature_t1: Tensor,
        feature_t2: Tensor,
        text_anchors: Tensor,
        label_t1: Tensor,
        label_t2: Tensor,
        change_mask: Tensor,
    ) -> dict[str, Tensor]:
        if feature_t1.shape != feature_t2.shape:
            raise ValueError("TASC requires aligned bi-temporal feature maps")
        size = feature_t1.shape[-2:]
        label_t1 = self._resize_label(label_t1, size)
        label_t2 = self._resize_label(label_t2, size)
        change_mask = self._resize_label(change_mask.long(), size).bool()
        valid = (label_t1 != self.ignore_index) & (label_t2 != self.ignore_index)
        changed = change_mask & valid
        unchanged = ~change_mask

        visual_t1 = F.normalize(feature_t1, dim=1)
        visual_t2 = F.normalize(feature_t2, dim=1)
        similarity = (visual_t1 * visual_t2).sum(dim=1)

        consistency = self._hard_consistency(similarity, unchanged, valid)
        if changed.any():
            distance = 1.0 - similarity[changed]
            repulsion = F.relu(self.margin - distance).mean()
        else:
            repulsion = _zero_like(similarity)

        projected_t1 = F.normalize(self.projector(feature_t1), dim=1)
        projected_t2 = F.normalize(self.projector(feature_t2), dim=1)
        anchors = F.normalize(text_anchors.detach().to(projected_t1), dim=1)
        anchor_t1 = self._anchor_alignment(
            projected_t1, anchors, label_t1, changed, valid
        )
        anchor_t2 = self._anchor_alignment(
            projected_t2, anchors, label_t2, changed, valid
        )
        anchor = 0.5 * (anchor_t1 + anchor_t2)
        total = consistency + repulsion + anchor
        return {
            "total": total,
            "consistency": consistency,
            "repulsion": repulsion,
            "anchor": anchor,
        }
